# ExamCloud

**No servers. No downtime. Just exams, scored the moment they're submitted.**

Every part of this platform — from serving the questions to grading the answers — runs without a single server to manage. Traffic spikes, idle hours, exam-day surges: the architecture handles all of it the same way, because there's nothing sitting around waiting to fall over.

| | |
|---|---|
| Architecture | 100% serverless — AWS Lambda, API Gateway, DynamoDB, S3, CloudFront |
| Author | Gagandeep — designed and built solo |
| License | MIT |

---

## The Idea

Traditional exam platforms need a server running around the clock, even when nobody's taking a test. This one flips that: every piece — question delivery, answer submission, scoring, storage — runs on-demand, in the cloud, and costs nothing when idle.

A student loads the exam, answers questions, hits submit — and the score comes back instantly, computed by a function that only existed for the few milliseconds it took to grade the paper.

## What It Does

- Serves exam questions from a secure backend, without ever exposing correct answers
- Accepts and validates student submissions in real time
- Grades every attempt automatically the moment it's submitted
- Persists every attempt and score for later review
- Scales from one student to thousands without any configuration change
- Locks down access with least-privilege IAM roles and CloudFront's Origin Access Control

## How It's Built

The system is a chain of fully managed AWS services, each doing exactly one job:

| Stage | Service | Job |
|---|---|---|
| Delivery | Amazon S3 + CloudFront | Serves the frontend fast, worldwide, over a locked-down private bucket |
| Entry point | Amazon API Gateway | Exposes the two HTTPS routes the frontend talks to, with CORS handled cleanly |
| Logic | AWS Lambda | Runs the actual exam logic — fetching questions, grading answers — on demand |
| Memory | Amazon DynamoDB | Holds every exam, every attempt, every score |
| Oversight | Amazon CloudWatch | Watches every Lambda execution and logs it for debugging |

### The Two Functions That Run the Whole Exam

- `getQuestions` — hands the student their exam, with correct answers stripped out
- `submitExam` — takes their answers, grades them, and writes the result to DynamoDB

### The Two Routes That Connect Them

- `GET /exams/{examId}/questions`
- `POST /exams/{examId}/submit`

## Built In This Order

1. Modeled the data first — `Exams` and `Attempts` tables in DynamoDB
2. Wrote the two Lambda functions that do all the real work
3. Wired them up through API Gateway, with CORS enabled from the start
4. Pushed the frontend to S3
5. Put CloudFront in front of it with Origin Access Control, so the bucket itself stays private
6. Ran the whole flow end to end — load questions, submit answers, watch the score land in DynamoDB

## My Contribution

Designed and built this entirely on my own — the architecture, both Lambda functions, the API routes, the IAM policies, and the frontend all came from a single build, not a team effort.

## Why Go Serverless

- No EC2 instance idling in the background, waiting for exam day
- No scaling decisions to make — the platform scales itself
- Pay only for the milliseconds of compute actually used
- Every layer — compute, database, delivery — fully managed
- Secure by default, with access locked to exactly what each function needs

## License

MIT
